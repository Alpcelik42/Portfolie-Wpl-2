document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("search-input");

    searchInput.addEventListener("input", function () {
        const searchTerm = searchInput.value.toLowerCase();

        // Filter producten op basis van zoekterm
        filteredProducts = productArray.filter(product =>
            product.name.toLowerCase().includes(searchTerm)
        );

        currentPage = 1; // Terug naar de eerste pagina
        renderProducts(filteredProducts, currentPage);
    });
});
