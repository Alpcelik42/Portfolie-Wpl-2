document.addEventListener("DOMContentLoaded", function () {
    const winkelmand = JSON.parse(localStorage.getItem('winkelmand')) || [];
    const overzicht = document.getElementById("afreken-overzicht");
    const totaalPrijsElement = document.getElementById("totaal-prijs");

    let totaalPrijs = 0;
    overzicht.innerHTML = winkelmand.map(item => {
        totaalPrijs += item.price * item.aantal;
        return `
                <div class="col-md-4 mb-4">
                    <div class="product-item">
                        <img src="${item.img}" alt="${item.name}" class="img-fluid">
                        <h3>${item.name}</h3>
                        <p>Prijs per stuk: €${item.price.toFixed(2)}</p>
                        <p>Aantal: ${item.aantal}</p>
                        <p>Subtotaal: €${(item.price * item.aantal).toFixed(2)}</p>
                    </div>
                </div>
            `;
    }).join("");

    totaalPrijsElement.textContent = `Totaalprijs: €${totaalPrijs.toFixed(2)}`;

    document.getElementById("bevestigen-btn").addEventListener("click", function () {
        alert("Bedankt voor uw bestelling! Uw bestelling wordt verwerkt.");
        localStorage.removeItem("winkelmand");
        window.location.href = "startpagina.html";
    });
});