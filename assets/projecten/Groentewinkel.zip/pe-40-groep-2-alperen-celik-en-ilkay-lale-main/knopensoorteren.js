document.addEventListener("DOMContentLoaded", () => {
    
    const sortPriceHighLowButton = document.getElementById("sort-price-high-low");
    const sortPriceLowHighButton = document.getElementById("sort-price-low-high");
    const sortAlphabeticalButton = document.getElementById("sort-alphabetical");

    
    const filterFruitButton = document.getElementById("filter-fruit");
    const filterVegetablesButton = document.getElementById("filter-vegetables");
    const resetFiltersButton = document.getElementById("reset-filters");

    
    const sortProducts = (compareFunction) => {
        filteredProducts.sort(compareFunction);
        currentPage = 1; // Terug naar de eerste pagina
        renderProducts(filteredProducts, currentPage);
    };

    
    sortPriceHighLowButton.addEventListener("click", () => {
        sortProducts((a, b) => b.price - a.price); // Hoog → Laag
    });

    sortPriceLowHighButton.addEventListener("click", () => {
        sortProducts((a, b) => a.price - b.price); // Laag → Hoog
    });

    sortAlphabeticalButton.addEventListener("click", () => {
        sortProducts((a, b) => a.name.localeCompare(b.name)); // A → Z
    });

    
    const filterProducts = (category) => {
        let filtered = productArray; // Toon alles standaard
        if (category === "fruit") {
            filtered = productArray.filter(product => ["appels", "banaan", "aardbei", "kiwi", "mango", "peren", "druiven", "ananas"].includes(product.name));
        } else if (category === "vegetables") {
            filtered = productArray.filter(product => ["tomaat", "komkommer", "spinazie", "bloemkool", "broccoli", "wortelen", "bonen"].includes(product.name));
        }
        renderProducts(filtered, 1); // Toon de eerste pagina
    };

    
    filterFruitButton.addEventListener("click", () => filterProducts("fruit"));
    filterVegetablesButton.addEventListener("click", () => filterProducts("vegetables"));
    resetFiltersButton.addEventListener("click", () => renderProducts(productArray, 1)); // Toon alles
});
