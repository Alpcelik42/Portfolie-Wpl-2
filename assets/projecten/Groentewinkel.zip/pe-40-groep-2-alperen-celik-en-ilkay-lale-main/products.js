const productList = document.getElementById("product-list");
const paginationContainer = document.getElementById("pagination");
const itemsPerPage = 6;
let currentPage = 1;
let filteredProducts = [...productArray];

function renderProducts(products, page = 1) {
    const start = (page - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const paginatedProducts = products.slice(start, end);

    productList.innerHTML = "";
    paginatedProducts.forEach(product => {
        const productHTML = `
            <div class="col-md-4 mb-4 product-item">
                <div class="product-item">
                    <a href="productdetails.html?id=${product.id}">
                        <img src="${product.img}" alt="${product.name}" class="img-fluid">
                    </a>
                    <h3>${product.name}</h3>
                    <p>Prijs: <strong>€${product.price.toFixed(2)}</strong></p>
                    <button class="btn btn-success" id="${product.id}">Voeg toe aan winkelwagen</button>
                    <button class="btn-favoriet" data-product-id="${product.id}">
                        <i class="fa-regular fa-heart"></i> Favoriet
                    </button>
                </div>
            </div>
        `;
        productList.innerHTML += productHTML;
    });

    renderPagination(products.length, page);
}


function renderPagination(totalItems, currentPage) {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    paginationContainer.innerHTML = "";

    if (totalPages === 0) {
        // Geen resultaten
        paginationContainer.innerHTML = "<p>Geen resultaten gevonden.</p>";
        return;
    }

    for (let i = 1; i <= totalPages; i++) {
        const pageButton = document.createElement("button");
        pageButton.classList.add("btn", "btn-secondary", "mx-1");
        pageButton.textContent = i;
        pageButton.disabled = i === currentPage;

        pageButton.addEventListener("click", () => {
            currentPage = i;
            renderProducts(filteredProducts, currentPage);
        });

        paginationContainer.appendChild(pageButton);
    }
}


renderProducts(filteredProducts, currentPage);



document.addEventListener("click", (event) => {
    if (event.target.classList.contains("btn-favoriet")) {
        const productId = event.target.getAttribute("data-product-id");
        voegToeAanFavorieten(productId);

        // Optioneel: Visuele feedback geven
        event.target.innerHTML = '<i class="fa-solid fa-heart"></i> Favoriet';
        alert("Product toegevoegd aan favorieten!");
    }
});


function voegToeAanFavorieten(productId) {
    const favorieten = JSON.parse(sessionStorage.getItem("favorieten")) || [];
    if (!favorieten.includes(productId)) {
        favorieten.push(productId);
        sessionStorage.setItem("favorieten", JSON.stringify(favorieten));
    }
}
