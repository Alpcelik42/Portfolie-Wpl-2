
function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}


const productId = getQueryParam("id");
const product = productArray.find(item => item.id === productId);


const productDetailContainer = document.getElementById("product-detail");

productDetailContainer.innerHTML =`
    <div class="col-md-6">
        <img src="${product.img}" alt="${product.name}" class="img-fluid rounded">
    </div>
<div class="col-md-6">
    <h1>${product.name}</h1>
    <p><strong>Prijs:</strong> €${product.price.toFixed(2)}</p>
    <p><strong>Voorraad:</strong> ${product.stock} beschikbaar</p>
    <p><strong>Beschrijving:</strong> ${product.description}</p>
    <button class="btn btn-success btn-lg" id="${product.id}">Voeg toe aan winkelwagen</button>
    <a href="products.html" class="btn btn-secondary btn-lg">Terug naar Producten</a>
</div>`;


