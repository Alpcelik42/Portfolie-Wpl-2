let submitBtn = document.querySelector('.submit');

submitBtn.addEventListener("click", submit)

function submit() {
    alert("Naam: " + document.getElementById("naam").value +
        "\nVan: " + document.getElementById("email").value +
        "\nOnderwerp: " + document.getElementById("onderwerp").value +
       "\nBericht: " +  document.getElementById("bericht").value);
}