
function getWinkelmand() {
    return JSON.parse(localStorage.getItem('winkelmand')) || [];
}

function saveWinkelmand(winkelmand) {
    localStorage.setItem('winkelmand', JSON.stringify(winkelmand));
}


document.addEventListener("click", (event) => {
    if (event.target.classList.contains("btn-success")) {
        const productId = event.target.id;
        const product = productArray.find(p => p.id === productId);
        const winkelmand = getWinkelmand();

        const bestaandeProduct = winkelmand.find(item => item.id === product.id);
        if (bestaandeProduct) {
            bestaandeProduct.aantal++;
        } else {
            winkelmand.push({ ...product, aantal: 1 });
        }

        saveWinkelmand(winkelmand);
        updateMandTeller();
    }
});


function renderWinkelmand() {
    const winkelmand = getWinkelmand();
    const winkelmandLijst = document.getElementById("winkelmand-lijst");
    const totaalPrijsElement = document.getElementById("totaal-prijs");

    winkelmandLijst.innerHTML = "";
    let totaalPrijs = 0;

    winkelmand.forEach(item => {
        console.log(item);
        totaalPrijs += item.price * item.aantal;
        let naam = item.name
        const productHTML = `
            <div class="col-md-4 mb-4">
                <div class="product-item">
                    <img src="${item.img}" alt="${item.name}" class="img-fluid">
                    <h3>${item.name}</h3>
                    <p>Prijs per stuk: €${item.price.toFixed(2)}</p>
                    <p>Aantal: ${item.aantal}</p>
                    <p>Subtotaal: €${(item.price * item.aantal).toFixed(2)}</p>

                    <button onclick="decreaseMandTeller('${naam}')" class="btn btn-danger" data-id="${item.id}">Verwijder</button>
                    <button onclick="increaseMandTeller('${naam}')" class="btn btn-danger" data-id="${item.id}">Toevoegen</button>

                </div>
            </div>
        `;
        winkelmandLijst.innerHTML += productHTML;
    });

    totaalPrijsElement.textContent = `Totaalprijs: €${totaalPrijs.toFixed(2)}`;
}



function updateMandTeller() {
    const winkelmand = getWinkelmand();
    const totaalAantal = winkelmand.reduce((acc, item) => acc + item.aantal, 0);
    document.getElementById("mand-teller").textContent = totaalAantal;
}


if (window.location.pathname.includes("winkelmand.html")) {
    renderWinkelmand();
}

function decreaseMandTeller(productName) {

    let winkelmand = getWinkelmand();


    console.log(productName);
    console.log(winkelmand);
    let product = winkelmand.find(item => item.name === productName);
    if (!product){
        alert("Product niet gevonden")
        return
    }
    if (product.aantal === 1) {
        winkelmand = winkelmand.filter(item => item.name !== productName);
    }
    else {
        product.aantal--;
    }
    saveWinkelmand(winkelmand);

    renderWinkelmand();
    updateMandTeller();
}
function increaseMandTeller(productName) {

    let winkelmand = getWinkelmand();

    let product = winkelmand.find(item => item.name === productName);


        if (product.aantal < product.stock) {
            product.aantal++;
    }

    saveWinkelmand(winkelmand);

    renderWinkelmand();
    updateMandTeller();
}


