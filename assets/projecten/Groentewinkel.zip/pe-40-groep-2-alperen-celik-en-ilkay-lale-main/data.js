let productArray = [
    {
        id: "01",
        name: "tomaat",
        price: 2.50,
        img:"assets/tomaten.jpg",
        stock: 50,
        description: "Verse, sappige tomaten, ideaal voor salades."
    },
    {
        id: "02",
        name: "komkommer",
        price: 2.50,
        img:"assets/komkommers.jpg",
        stock: 30,
        description: "Krokante komkommers, perfect voor frisse gerechten."
    },
    {
        id: "03",
        name: "paprika",
        price: 3.00,
        img:"assets/paprika's.jpg",
        stock: 20,
        description: "Kleurige paprika's, ideaal voor stir-fry of salades."
    },
    {
        id: "04",
        name: "wortelen",
        price: 1.50,
        img:"assets/wortelen.jpg",
        stock: 40,
        description: "Zoete wortelen, perfect voor koken of rauw in een salade."
    },
    {
        id: "05",
        name: "spinazie",
        price: 2.20,
        img:"assets/spinazie.jpg",
        stock: 35,
        description: "Verse spinazie, rijk aan ijzer en vitaminen."
    },
    {
        id: "06",
        name: "bonen",
        price: 2.80,
        img:"assets/boontjes.jpg",
        stock: 25,
        description: "Heerlijke boontjes, goed voor een voedzame maaltijd."
    },
    {
        id: "07",
        name: "bloemkool",
        price: 2.10,
        img:"assets/bloemkool.jpg",
        stock: 15,
        description: "Knapperige bloemkool, ideaal voor een gezonde maaltijd."
    },
    {
        id: "08",
        name: "broccoli",
        price: 2.70,
        img:"assets/broccoli.jpg",
        stock: 50,
        description: "Rijke, groene broccoli, boordevol vitaminen."
    },
    {
        id: "09",
        name: "aardappelen",
        price: 1.90,
        img:"assets/aardappelen.jpg",
        stock: 60,
        description: "Vaste aardappelen, perfect voor bakken of pureren."
    },
    {
        id: "10",
        name: "appels",
        price: 2.50,
        img:"assets/appels.jpg",
        stock: 45,
        description: "Lekkere, frisse appels, ideaal voor tussendoor."
    },
    {
        id: "11",
        name: "banaan",
        price: 1.80,
        img:"assets/bananen.jpg",
        stock: 50,
        description: "Zoete bananen, rijk aan kalium."
    },
    {
        id: "12",
        name: "mandarijnen",
        price: 2.00,
        img:"assets/mandarijnen.jpg",
        stock: 30,
        description: "Lekkere, sappige mandarijnen voor een verfrissend tussendoortje."
    },
    {
        id: "13",
        name: "druiven",
        price: 3.50,
        img:"assets/druiven.jpg",
        stock: 40,
        description: "Zoete druiven, ideaal als snack of in een fruitsalade."
    },
    {
        id: "14",
        name: "mango",
        price: 2.80,
        img:"assets/mango.jpg",
        stock: 25,
        description: "Rijpe mango's, lekker zoet en tropisch."
    },
    {
        id: "15",
        name: "peren",
        price: 2.40,
        img:"assets/peren.jpg",
        stock: 40,
        description: "Verse peren, heerlijk voor in salades of als snack."
    },
    {
        id: "16",
        name: "aardbei",
        price: 3.00,
        img:"assets/aardbei.jpg",
        stock: 50,
        description: "Zoete, sappige aardbeien, perfect voor desserts."
    },
    {
        id: "17",
        name: "ananas",
        price: 3.20,
        img:"assets/ananas.jpg",
        stock: 30,
        description: "Frisse, tropische ananas, vol vitaminen."
    },
    {
        id: "18",
        name: "kiwi",
        price: 2.60,
        img:"assets/kiwi.jpg",
        stock: 20,
        description: "Zure, sappige kiwi's, rijk aan vitamine C."
    },
];