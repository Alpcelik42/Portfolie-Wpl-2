const favorietenContainer = document.getElementById("favorieten-container");


function voegToeAanFavorieten(productId) {

    const favorieten = JSON.parse(sessionStorage.getItem("favorieten")) || [];

    if (!favorieten.includes(productId)) {
        favorieten.push(productId);
        sessionStorage.setItem("favorieten", JSON.stringify(favorieten));
    }
}


function toonFavorieten() {
    const favorieten = JSON.parse(sessionStorage.getItem("favorieten")) || [];

    // Clear de container
    favorietenContainer.innerHTML = "";

    if (favorieten.length === 0) {
        favorietenContainer.innerHTML = "<p>Geen favorieten gevonden.</p>";
        return;
    }


    favorieten.forEach((id) => {
        const product = productArray.find((p) => p.id === id);
        if (product) {
            const favorietHTML = `
                <div class="col-md-4 mb-4">
                    <div class="product-item">
                        <img src="${product.img}" alt="${product.name}" class="img-fluid">
                        <h3>${product.name}</h3>
                        <p>Prijs: <strong>€${product.price.toFixed(2)}</strong></p>
                        <button class="btn btn-danger" data-product-id="${product.id}">Verwijder</button>
                    </div>
                </div>
            `;
            favorietenContainer.innerHTML += favorietHTML;
        }
    });

    const verwijderKnoppen = favorietenContainer.querySelectorAll(".btn-danger");
    verwijderKnoppen.forEach((knop) => {
        knop.addEventListener("click", (e) => {
            const productId = e.target.getAttribute("data-product-id");
            verwijderUitFavorieten(productId);
        });
    });
}


function verwijderUitFavorieten(productId) {
    const favorieten = JSON.parse(sessionStorage.getItem("favorieten")) || [];
    const nieuweFavorieten = favorieten.filter((id) => id !== productId);
    sessionStorage.setItem("favorieten", JSON.stringify(nieuweFavorieten));


    toonFavorieten();
}


toonFavorieten();
