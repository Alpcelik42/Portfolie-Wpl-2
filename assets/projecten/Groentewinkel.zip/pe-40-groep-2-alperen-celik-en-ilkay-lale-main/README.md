[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/WZSjdgeR)

Groente & Fruit Winkel Webapplicatie

Welkom bij de Groente & Fruit Winkel Webapplicatie! Deze applicatie biedt gebruikers de mogelijkheid om groente- en fruitproducten te bekijken, favorieten op te slaan, producten aan de winkelwagen toe te voegen, en producten te sorteren of filteren.

Overzicht

Dit project is ontwikkeld als onderdeel van [vul opdracht/module in]. Het combineert HTML, CSS en JavaScript om een interactieve webshop te bouwen. De belangrijkste functionaliteiten zijn:

Producten weergeven met paginering.

Favorieten opslaan en beheren.

Een winkelwagen met teller en overzicht.

Filteren en sorteren van producten.

Functies

1. Producten weergeven

Alle producten worden weergegeven in een overzicht met maximaal 6 producten per pagina. Gebruikers kunnen navigeren door pagina's met behulp van paginering.

2. Zoek- en sorteerfuncties

Zoek op naam met een zoekbalk.

Sorteer producten op:

Prijs (hoog → laag of laag → hoog).

Alfabetische volgorde (A → Z).

Filter producten op categorie:

Alleen fruit.

Alleen groenten.

3. Favorieten beheren

Klik op het hart-icoon bij een product om het aan de favorieten toe te voegen.

Favorieten worden tijdelijk opgeslagen en geleegd bij het sluiten van de browser.

Een verwijderknop is beschikbaar op de favorietenpagina.

4. Winkelwagen beheren

Voeg producten toe aan de winkelwagen en bekijk het aantal geselecteerde producten via de teller in de navigatiebalk.

Bekijk de winkelwagenpagina om toegevoegde producten te zien.

5. Contactpagina

De contactpagina biedt een formulier waarmee gebruikers vragen of opmerkingen kunnen indienen.

Velden zoals naam, e-mailadres en bericht zijn aanwezig.

6. Afrekenpagina

De afrekenpagina laat gebruikers het bestelproces afronden.

Het toont een overzicht van de winkelwagen en biedt een knop om de bestelling te bevestigen.

7. Reviewpagina

Gebruikers kunnen beoordelingen achterlaten voor producten die ze hebben gekocht.

Dit helpt andere klanten om betere keuzes te maken.

8. Responsief design

De applicatie is volledig geoptimaliseerd voor zowel desktop- als mobiele apparaten dankzij Bootstrap.

Projectstructuur

project-folder/
│
├── startpagina.html        # Startpagina
├── products.html           # Productenpagina
├── favorieten.html         # Favorietenpagina
├── winkelmand.html         # Winkelwagenpagina
├── afrekenpagina.html      # Afrekenpagina
├── contact.html            # Contactpagina
├── review.html             # Reviewpagina
├── style.css               # CSS-styling
├── products.js             # Logica voor producten
├── winkelmand.js           # Logica voor winkelwagen
├── favorieten.js           # Logica voor favorieten
├── afrekenpagina.js        # Logica voor afrekenen
├── contact.js              # Logica voor contactformulier
├── zoekfunctie.js          # Logica voor zoekfunctionaliteit
├── knopensorteren.js       # Logica voor sorteerfuncties
├── README.md               # Documentatie
├── assets/                 # Afbeeldingen en icons
└── data.js                 # Bevat productdata (array)

Installatie en Gebruik

Benodigdheden

Een moderne webbrowser zoals Chrome, Firefox, Edge of Safari.

Optioneel: een lokale server zoals Live Server in VS Code.

Installatie

Clone het projectClone het project naar je lokale machine via Git:

git clone <repository-url>

Open de bestandenOpen de bestanden in een code-editor zoals Visual Studio Code of direct in de browser.

Gebruik een lokale server (optioneel)Gebruik bijvoorbeeld Live Server in VS Code:


Klik met de rechtermuisknop op startpagina.html.

Selecteer "Open met Live Server".

Toegang tot de applicatie

Startpagina: startpagina.html

Productenpagina: products.html

Favorietenpagina: favorieten.html

Winkelwagenpagina: winkelmand.html

Afrekenpagina: afrekenpagina.html

Contactpagina: contact.html

Reviewpagina: review.html


Technische Details

Data-opslag:
Tijdelijke opslag in localStorage of sessionStorage.

Interactiviteit:
JavaScript wordt gebruikt om dynamisch elementen te genereren, zoals filters, paginering en favorieten.


Bekende Problemen

Favorieten legen bij herstarten: Favorieten worden alleen opgeslagen tijdens een actieve sessie. Dit is een bewuste keuze volgens de opdrachtvereisten.

Geen backend: Dit project heeft geen backend. Alle data wordt lokaal in de browser verwerkt.


Mogelijke Uitbreidingen

Persistente opslag: Gebruik een backend of een database om favorieten en winkelwagenitems permanent op te slaan.

Gebruikersaccounts: Voeg functionaliteit toe voor inloggen en persoonlijke instellingen.

Bestelfunctionaliteit: Voeg een bestelproces toe met een checkout-pagina.


Teamleden

Alperen Ozcelik -
Ilkay Lale -
