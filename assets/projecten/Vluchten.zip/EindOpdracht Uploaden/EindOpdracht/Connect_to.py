import mysql.connector
import os
from mysql.connector import Error

cursor = ""

def MaakConnectie():
    global mysqlConn
    
    try:
        mysqlConn = mysql.connector.connect(
            host = 'localhost',
            port = 3306,
            database = "vluchtboekingen",
            user = 'root',
            password = 'Celikalp70.'
        )
        
        if mysqlConn.is_connected():
            return mysqlConn
        
    except Error as e:
        print("Verbinding Mislukt",e)

def SluitConnectie():
    if mysqlConn.is_connected():
        mysqlConn.close()
