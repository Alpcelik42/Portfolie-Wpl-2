import qrcode
from reportlab.pdfgen import canvas
from reportlab.lib import colors
import os

def maakpdf(vlucht):
    bestandsnaam = "vluchtgegevens.pdf"
    title = "Vluchtgegevens"

    pdf = canvas.Canvas(bestandsnaam)
    pdf.setTitle(title)
    pdf.setFont("Courier", 15)
    pdf.drawString(270, 780, title)

    text = pdf.beginText(40, 720)
    text.setFont("Courier", 11)
    text.setFillColor(colors.black)
    text.textLine(f"{'Vlucht ID':^10}{'Vertrekuur':^15}{'Vertrekdatum':^15}{'Aankomstuur':^15}{'Max Passagier':^15}{'Maatschappij':^15}")
    text.textLine("_" * 140)
    text.textLine()

  
    text.textLine(f"{vlucht[0]:^10}{vlucht[1]:^15}{vlucht[2]:^15}{vlucht[3]:^15}{vlucht[4]:^15}{vlucht[5]:^15}")

    for teller in range(5):
        text.textLine()
        

    pdf.drawText(text)


    vlucht_info = f"{vlucht[0]} - {vlucht[1]} - {vlucht[2]} - {vlucht[3]} - {vlucht[4]} - {vlucht[5]} - {vlucht[6]}"
    generate_qr_code(vlucht_info, pdf)

    pdf.drawInlineImage("fotos/vlucht.jpg",60,470)
    
    pdf.save()
    os.startfile("vluchtgegevens.pdf")


def generate_qr_code(tekst, pdf):
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=5, border=4)
    qr.add_data(tekst)
    qr.make(fit=True)
    img = qr.make_image(fill_color="Black", back_color="White")
    img.save("qrcode.png")
    
    pdf.drawInlineImage("qrcode.png", 50, 300)