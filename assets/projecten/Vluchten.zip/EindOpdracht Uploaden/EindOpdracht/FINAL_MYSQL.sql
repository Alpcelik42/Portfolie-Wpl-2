-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: vluchtboekingen
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblgebruikersnaam`
--

DROP TABLE IF EXISTS `tblgebruikersnaam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblgebruikersnaam` (
  `gebruikers_id` int NOT NULL AUTO_INCREMENT,
  `gebruikersnaam` varchar(70) NOT NULL,
  `paswoord` varchar(70) NOT NULL,
  PRIMARY KEY (`gebruikers_id`),
  UNIQUE KEY `gebruikersid_UNIQUE` (`gebruikers_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgebruikersnaam`
--

LOCK TABLES `tblgebruikersnaam` WRITE;
/*!40000 ALTER TABLE `tblgebruikersnaam` DISABLE KEYS */;
INSERT INTO `tblgebruikersnaam` VALUES (1,'Alperen','Admin'),(2,'bert','bert'),(3,'CRISSSS','$2b$12$B7nd9lX9EnRfVSH6cz9tO.h8yBYKYTXmJEiTbObKuvwiNpQpz5JZq'),(4,'aap','$2b$12$8Ckq9EuuoiHnXvzYUsOgOeux61MVbJBHmK126hkX9/WIWl0t7/6iy'),(5,'aap2','$2b$12$/KXCmrop2qCIDb3J9Nvg6Op2Ze5W5/VQzrSkA2kOOK3WZE2JW6x4m'),(6,'aap3','$2b$12$RULhHKXeFNXKO3KJKFDTmu1L2rzFFk9cJoZ6ydIF64cxAVRTbaI1.'),(7,'aap@hotmail.com','$2b$12$.lKG.6JTSyeBNrVVENaw0O.1OZygVRqtx4E4muR.1CEO4kFj6wgNO'),(8,'ok@hotmail.com','$2b$12$1ozA3Q0zKTAy5j9EVKG6ZOY.nQmp4zZfAI//C7jtG65tL.h4lc9k.');
/*!40000 ALTER TABLE `tblgebruikersnaam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpassagiers`
--

DROP TABLE IF EXISTS `tblpassagiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblpassagiers` (
  `passagier_id` int NOT NULL AUTO_INCREMENT,
  `naam` varchar(45) NOT NULL,
  `voornaam` varchar(45) NOT NULL,
  `geboortedatum` varchar(20) NOT NULL,
  `postcode` varchar(20) NOT NULL,
  `adres` varchar(100) NOT NULL,
  `land` varchar(100) NOT NULL,
  PRIMARY KEY (`passagier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpassagiers`
--

LOCK TABLES `tblpassagiers` WRITE;
/*!40000 ALTER TABLE `tblpassagiers` DISABLE KEYS */;
INSERT INTO `tblpassagiers` VALUES (23,'Alperen','Ozcelik','1/01/2024','3550','klankerlaan','Azerbajdsjan\n'),(24,'Aap','laan','9/01/2024','5550','laaan','Azerbajdsjan\n'),(26,'Tom','Vangriek','14/06/1976','2590','Looplaan 405','Letland\n'),(27,'Paul','Van Der Veld','7/04/2023','3545','Huislaan 23','Kaapverdie\n'),(28,'Jan','Jermy','2098-01-15','3550','Aaplaan','Duitse Democratische Republiek'),(29,'ddzd','zeze','9/01/2024','1220','zerze','Ascension\n'),(31,'sfsfs','sfdsfs','15/01/2024','3000','fsqfsqf','Azerbajdsjan\n'),(32,'dzadaz','eazrer','8/01/2024','1200','hfhfh','Ascension\n'),(33,'fgj','ghj','31/01/2024','1111','vg','Ascension\n'),(34,'Aghfh','ryhtry','15/01/2024','1200','tyrzy','Azerbajdsjan\n'),(35,'','','31/01/2022','','','Griekenland\n'),(36,'','','31/01/2022','','','Griekenland\n'),(37,'ertet','tet','31/01/2022','1000','hjdh','Azerbajdsjan\n');
/*!40000 ALTER TABLE `tblpassagiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpassagiervlucht`
--

DROP TABLE IF EXISTS `tblpassagiervlucht`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblpassagiervlucht` (
  `passagiervlucht_id` int NOT NULL AUTO_INCREMENT,
  `Passagier_id` int NOT NULL,
  `vlucht_id` int NOT NULL,
  `aankofers` int NOT NULL,
  `gewicht` double NOT NULL,
  PRIMARY KEY (`passagiervlucht_id`),
  UNIQUE KEY `passagiervlucht_id_UNIQUE` (`passagiervlucht_id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpassagiervlucht`
--

LOCK TABLES `tblpassagiervlucht` WRITE;
/*!40000 ALTER TABLE `tblpassagiervlucht` DISABLE KEYS */;
INSERT INTO `tblpassagiervlucht` VALUES (1,1,1,0,0),(2,3,3,10,300),(3,1,1,0,0),(4,23,3,0,0),(5,23,1,10,400),(6,25,3,0,0),(7,23,3,0,0),(8,23,7,0,0),(9,23,7,23,10000),(10,23,7,0,0),(11,23,7,0,0),(12,25,7,0,0),(13,25,6,0,0),(14,25,5,0,0),(15,23,7,0,0),(16,23,7,0,0),(17,23,7,0,0),(18,23,0,0,0),(19,23,0,0,0),(20,25,0,0,0),(21,24,0,0,0),(22,23,0,0,0),(23,23,0,0,0),(24,23,0,0,0),(25,23,0,0,0),(26,23,0,0,0),(27,24,0,0,0),(28,25,0,0,0),(29,23,0,0,0),(30,23,0,0,0),(31,24,0,0,0),(32,23,0,0,0),(33,23,0,0,0),(34,23,0,0,0),(35,23,0,0,0),(36,23,0,0,0),(37,23,0,0,0),(38,23,0,0,0),(39,23,7,0,0),(40,23,7,0,0),(41,23,7,0,0),(42,23,7,0,0),(43,23,7,0,0),(44,23,7,0,0),(45,23,7,0,0),(46,23,7,0,0),(47,23,7,0,0),(48,23,7,0,0),(49,23,7,0,0),(50,23,7,0,0),(51,23,7,0,0),(52,23,7,0,0),(53,23,7,0,0),(54,23,7,0,0),(55,23,7,0,0),(56,23,7,0,0),(57,23,7,0,0),(58,23,7,0,0),(59,23,7,0,0),(60,23,7,0,0),(61,23,7,0,0),(62,23,7,0,0),(63,23,7,0,0),(64,23,7,0,0),(65,23,7,0,0),(66,23,6,10,1000),(67,23,7,0,0),(68,23,7,0,0),(69,23,7,0,0),(70,23,7,0,0),(71,23,7,0,0),(72,23,7,0,0),(73,23,7,0,0),(74,23,7,0,0),(75,23,7,10,100),(76,23,7,0,0),(77,23,11,0,0),(78,23,10,0,0),(79,23,11,0,0),(80,23,11,0,0),(81,23,11,0,0),(82,23,7,0,0),(83,23,7,0,0),(84,23,12,0,0),(85,23,9,5,100),(86,23,11,0,0),(87,23,8,0,0),(88,23,9,0,0),(89,23,8,0,0),(90,23,10,5,100),(91,23,11,0,0),(92,23,9,10,30),(93,23,8,5,50),(94,23,13,0,0),(95,23,13,30,600),(96,23,10,10,300);
/*!40000 ALTER TABLE `tblpassagiervlucht` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblvlucht`
--

DROP TABLE IF EXISTS `tblvlucht`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblvlucht` (
  `vlucht_id` int NOT NULL AUTO_INCREMENT,
  `vertrekuur` varchar(100) NOT NULL,
  `vertrekdatum` varchar(100) NOT NULL,
  `aankomstuur` varchar(100) NOT NULL,
  `maxpassagier` int NOT NULL,
  `maatschappij` varchar(100) NOT NULL,
  `prijs` int NOT NULL,
  PRIMARY KEY (`vlucht_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblvlucht`
--

LOCK TABLES `tblvlucht` WRITE;
/*!40000 ALTER TABLE `tblvlucht` DISABLE KEYS */;
INSERT INTO `tblvlucht` VALUES (1,'14:00','15/01/2024','13:00',4,'Japan Airlines',0),(3,'14:00','22/01/2024','14:00',4,'Qatar Airways',0),(4,'09:00','7/01/2024','15:00',6,'Aer Lingus',0),(5,'16:00','28/01/2024','22:00',6,'Pegasus Airlines		\n',0),(6,'04:30','14/01/2024','18:45',10,'Singapore Airlines		\n',0),(7,'12:00','7/01/2024','13:00',12,'Lufthansa		\n',2000),(8,'19:00','15/01/2024','20:00',9,'Air France		\n',1000),(9,'23:00','2/01/2024','06:00',4,'Pegasus Airlines		\n',900),(10,'05:00','17/01/2024','18:00',2,'Japan Airlines		\n',1600),(11,'19:00','16/02/2024','22:00',4,'Lufthansa		\n',600),(12,'12:00','26/01/2024','16:00',1,'Lufthansa		\n',300),(13,'20:00','8/01/2024','12:00',4,'Qatar Airways		\n',750),(14,'12:00','8/01/2024','23:00',4,'Singapore Airlines		\n',6000),(15,'12:00','3/01/2024','13:00',8,'Lufthansa		\n',200);
/*!40000 ALTER TABLE `tblvlucht` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-31 15:08:00
