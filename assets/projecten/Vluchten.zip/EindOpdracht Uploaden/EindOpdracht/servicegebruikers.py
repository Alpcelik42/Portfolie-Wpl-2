from Connect_to import MaakConnectie,SluitConnectie

def addgebruiker(gebruiker, pasw):
    connectie = MaakConnectie()
    if connectie is None:
        return None
    cur = connectie.cursor()
    cur.execute(f"INSERT INTO tblgebruikersnaam (gebruikersnaam, paswoord) VALUES ('{gebruiker}', '{pasw}')")
    connectie.commit()
    SluitConnectie()
    return cur.rowcount

def getgebruikers(gebr):
    connectie = MaakConnectie()
    if connectie is None:
        return None
    cur = connectie.cursor()
    cur.execute(f"SELECT gebruikersnaam, paswoord FROM tblgebruikersnaam WHERE gebruikersnaam = '{gebr}'")
    rows = cur.fetchall()
    connectie.close()
    return rows

