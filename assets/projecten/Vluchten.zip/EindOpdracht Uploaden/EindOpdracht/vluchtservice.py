from Connect_to import MaakConnectie,SluitConnectie

def bewaar_klant(vertrekuur,vertrekdatum,aankomstuur,maxpassagier,maatschappij,prijs):
    connectie = MaakConnectie()
    if connectie is None:
        return None

    cur = connectie.cursor()
    cur.execute(
        f"INSERT INTO tblvlucht (vertrekuur,vertrekdatum,aankomstuur,maxpassagier,maatschappij,prijs) VALUES \
        ('{vertrekuur}','{vertrekdatum}','{aankomstuur}','{maxpassagier}','{maatschappij}','{prijs}')"
    )
    
    connectie.commit()
    SluitConnectie()
    return cur.rowcount


def verwijder_klant(id):
    connectie = MaakConnectie()
    if connectie is None:
        return None

    cur = connectie.cursor()
    cur.execute(f"DELETE FROM tblvlucht WHERE vlucht_id= {id}")
    connectie.commit()
    SluitConnectie()
    return cur.rowcount

def wijzigpassagier(vlucht_id,vertrekuur,vertrekdatum,aankomstuur,maxpassagier,maatschappij,prijs):
    print(vlucht_id)
    connectie = MaakConnectie()
    if connectie is None:
        return None
    cur = connectie.cursor()
    cur.execute(f"""UPDATE tblvlucht
                    SET
                    vertrekuur = '{vertrekuur}',
                    vertrekdatum = '{vertrekdatum}',
                    aankomstuur = '{aankomstuur}',
                    maxpassagier = '{maxpassagier}',
                    maatschappij = '{maatschappij}',
                    prijs = '{prijs}'
                    

                    WHERE
                    vlucht_id = {vlucht_id}""")
    
    connectie.commit()
    SluitConnectie()
    return cur.rowcount

def toonklanten():
    connectie = MaakConnectie()
    if connectie is None:
        return None

    cur = connectie.cursor()
    cur.execute("SELECT * FROM tblvlucht ")
    rows = cur.fetchall()
    SluitConnectie()
    return rows
