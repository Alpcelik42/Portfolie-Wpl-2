from Connect_to import MaakConnectie,SluitConnectie

def bewaar_klant(naam,voornaam,geboortedatum,postcode,adres,land):
    connectie = MaakConnectie()
    if connectie is None:
        return None

    cur = connectie.cursor()
    cur.execute(
        f"INSERT INTO tblpassagiers (naam,voornaam,geboortedatum,postcode,adres,land) VALUES \
        ('{naam}','{voornaam}','{geboortedatum}','{postcode}','{adres}','{land}')"
    )
    
    connectie.commit()
    SluitConnectie()
    return cur.rowcount


def verwijder_klant(id):
    connectie = MaakConnectie()
    if connectie is None:
        return None

    cur = connectie.cursor()
    cur.execute(f"DELETE FROM tblpassagiers WHERE passagier_id = {id}")
    connectie.commit()
    SluitConnectie()
    return cur.rowcount


def wijzigpassagier(vlucht_id,vertrekuur,vertrekdatum,aankomstuur,maxpassagier,maatschappij):
    print(vlucht_id)
    connectie = MaakConnectie()
    if connectie is None:
        return None
    cur = connectie.cursor()
    cur.execute(f"""UPDATE tblvlucht
                    SET
                    vertrekuur = '{vertrekuur}',
                    vertrekdatum = '{vertrekdatum}',
                    aankomstuur = '{aankomstuur}',
                    maxpassagier = '{maxpassagier}',
                    maatschappij = '{maatschappij}'


                    WHERE
                    vlucht_id = {vlucht_id}""")
    
    connectie.commit()
    SluitConnectie()
    return cur.rowcount

def toonklanten():
    connectie = MaakConnectie()
    if connectie is None:
        return None

    cur = connectie.cursor()
    cur.execute("SELECT * FROM tblpassagiers ")
    rows = cur.fetchall()
    SluitConnectie()
    return rows

def selecteerpassagiers():
    connectie = MaakConnectie()
    if connectie is None:
        return None
    cur = connectie.cursor()
    cur.execute("SELECT * FROM tblvlucht")  
    rows = cur.fetchall()
    SluitConnectie()
    
    return rows

def vlucht_by_id(id):
    connectie = MaakConnectie()
    if connectie is None:
        return None
    cur = connectie.cursor()
    cur.execute(f"SELECT * FROM tblpassagiers WHERE passagier_id = {id}")  
    rows = cur.fetchall()
    SluitConnectie()

    return rows

def vlucht_by_name(maatschappij):
    connectie = MaakConnectie()
    if connectie is None:
        return None
    cur = connectie.cursor()
    cur.execute(f"SELECT * FROM tblvlucht WHERE maatschappij like '%{maatschappij}%'")  
    rows = cur.fetchall()
    SluitConnectie()

    return rows


def boek_vlucht(Passagier_id, vlucht_id, aankofers, gewicht):
    connectie = MaakConnectie()
    if connectie is None:
        return None

    cur = connectie.cursor()
    cur.execute(
        f"INSERT INTO tblpassagiervlucht (Passagier_id, vlucht_id, aankofers, gewicht) VALUES \
        ({Passagier_id}, {vlucht_id}, {aankofers}, {gewicht})"
    )
    
    connectie.commit()
    SluitConnectie()
    return cur.rowcount


def get_passagier_details(passagier_id):
    connectie = MaakConnectie()
    if connectie is None:
        return None

    cur = connectie.cursor()
    cur.execute(f"SELECT * FROM tblpassagiers WHERE passagier_id = {passagier_id}")
    passagier_record = cur.fetchone()
    SluitConnectie()
    return passagier_record


def get_airlines():
    conn = MaakConnectie()

    airlines = {}
    cursor = conn.cursor()
    query = "SELECT maatschappij, COUNT(*) FROM tblvlucht GROUP BY maatschappij"
    cursor.execute(query)
    result = cursor.fetchall()
    for row in result:
        airlines[row[0]] = row[1]

    cursor.close()
    conn.close()

    return airlines
