import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from tkinter.ttk import Combobox
import vluchtservice


waardencategorie = []

def is_admin():
    return False

def openform(lijst_passagiers,toongeg):
    def toon_product():
        print(lijst_passagiers)
        wid_entry.insert(0,lijst_passagiers[0])
        wvertrekuur_entry.insert(0,lijst_passagiers[1])
        wvertrekdatum_entry.insert(0,lijst_passagiers[2])
        waankomstuur_entry.insert(0,lijst_passagiers[3])
        wmaxpassagier_entry.insert(0,lijst_passagiers[4])
        wmaatschappij_combo.set(lijst_passagiers[5])
        wprijs_entry.insert(0,lijst_passagiers[6])
        
        wid_entry.config(state="readonly")
        
        
    def wijzig_item(): 
    
        pid = wid_entry.get()
        record = vluchtservice.wijzigpassagier(pid,wvertrekuur.get(),wvertrekdatum.get(),waankomstuur.get(),wmaxpassagier.get(),wmaatschappij_combo.get(),wprijs.get())
        
        if record > 0:
            messagebox.showinfo("Controle","De vlucht is opgeslagen")
            toongeg()
            sluitform()
        else:
            messagebox.showinfo("Controle","De vlucht is NIET opgeslagen")
    
    def sluitform():
        passagiersform.destroy()
    
    passagiersform = tk.Toplevel()
    passagiersform.title("Wijzig vlucht")
    passagiersform.geometry("800x800")
        
    
    wid_label = tk.Label(passagiersform,text="vlucht_id")
    wvertrekuur_label=tk.Label(passagiersform,text = "vertrekuur")
    wvertrekdatum_label=tk.Label(passagiersform,text = "vertrekdatum")
    waankomstuur_label= tk.Label(passagiersform,text= "aankomstuur")
    wmaxpassagier_label= tk.Label(passagiersform,text= "maxpassagier")
    wmaatschappij_label = tk.Label(passagiersform,text= "maatschappij")
    wprijs_label = tk.Label(passagiersform,text= "Prijs")
        
        
    wID = tk.StringVar()
    wvertrekuur = tk.StringVar()
    wvertrekdatum = tk.StringVar()
    waankomstuur = tk.StringVar()
    wmaxpassagier = tk.StringVar()
    wmaatschappij = tk.StringVar()
    wprijs = tk.IntVar()
        
    bestand = open("maatsch.txt","r")
    maatschappij = []
    for item in bestand:
        maatschappij.append(item.strip())
        
        
    wid_entry= tk.Entry(passagiersform,textvariable=wID,width="25")
    wvertrekuur_entry=tk.Entry(passagiersform,textvariable = wvertrekuur,width="30")
    wvertrekdatum_entry=tk.Entry(passagiersform,textvariable = wvertrekdatum,width="50")
    waankomstuur_entry=tk.Entry(passagiersform,textvariable = waankomstuur,width="30")
    wmaxpassagier_entry=tk.Entry(passagiersform,textvariable = wmaxpassagier,width="30")
    wmaatschappij_combo=Combobox(passagiersform, values=maatschappij ,width="15",height="10")
    wprijs_entry=tk.Entry(passagiersform,textvariable = wprijs,width="30")
    
    passagiersform.bind("<Map>",toon_product())


    sluit_button = tk.Button(passagiersform,text = "sluiten",command=sluitform, width="15", height="2",bg="slategrey", fg="black")
    wijzig_button = tk.Button(passagiersform,text = "Wijzig",command=wijzig_item, width="15", height="2",bg="slategrey", fg="black")

    
    wid_label.place(x=15,y = 20)
    wid_entry.place(x=120,y = 20)

    wvertrekuur_label.place(x=15, y =50)
    wvertrekuur_entry.place(x = 120, y = 50)
        
    wvertrekdatum_label.place(x = 15, y = 80)
    wvertrekdatum_entry.place(x = 120, y = 80)
        
    waankomstuur_label.place(x =15 , y = 110)
    waankomstuur_entry.place(x =120, y = 110)
        
    wmaxpassagier_label.place(x = 15 , y = 140)
    wmaxpassagier_entry.place(x = 120,y = 140)
        
    wmaatschappij_combo.place(x=120 , y= 170)
    wmaatschappij_label.place(x=15 , y=170 )
    
    wprijs_label.place(x=15,y=200)
    wprijs_entry.place(x=120,y=200)
    
    sluit_button.place(x= 15, y=220)
    wijzig_button.place(x = 150 , y=220)
    
    
def main():
    def open_sub():
        if mijn_tree.focus():
            record = mijn_tree.focus()
            lijst_passagiers = mijn_tree.item(record,"values")
            openform(lijst_passagiers,toonklant)
        
    def validatie():
        if vertrekuur.get() == "":
            messagebox.showinfo("Controle","U moet een vertrekuur ingeven!")
            return None
        
        elif vertrekdatum_input.entry.get() =="":
            messagebox.showinfo("Controle","U moet een vertrekdatum ingeven!")
            return None
        
        elif aankomstuur.get() == "":
            messagebox.showinfo("Controle","U moet een aankomstuur ingeven!")
            return None
        
        elif maxpassagier.get() == "":
            messagebox.showinfo("Controle","Er is geen geldig maxpassagier opgegeven.")
            return None
        
        elif maatschappij_combo.get() == "":
            messagebox.showinfo("Controle", "Selecteer een maatschappij a.u.b")
            return None
        
        elif prijs.get() == "":
            messagebox.showinfo("Controle", "Selecteer een prijs a.u.b")
            return None
        return True

    def bewaren():
        if validatie():
            uitkomst =  vluchtservice.bewaar_klant(vertrekuur.get(),vertrekdatum_input.entry.get(),aankomstuur.get(),maxpassagier.get(),maatschappij_combo.get(),prijs.get())
            if  uitkomst > 0:
                messagebox.showinfo("Controle","De vlucht is toegevoegd")
                maakleeg()
                toonklant()
            else:
                messagebox.showwarning("Controle","De vlucht is niet toegevoegd")
          
    def maakleeg():
        vertrekuur_input.delete(0,END)
        vertrekdatum_input.entry.delete(0,END)
        aankomstuur_input.delete(0,END)
        maxpassagier_input.delete(0,END)
        maatschappij_combo.set("")
        prijs_input.delete(0,END)
        vertrekuur_input.focus_get()
    
    
                
    def sluiten():      
        windowproduct.destroy()

    def toonklant(*event):
        lijstlanden = []
        bestand = open("maatsch.txt","r")
        
        for item in bestand:
            lijstlanden.append(item)
        maatschappij_combo.config(value =lijstlanden)
        
        rijen = vluchtservice.toonklanten()
        
        for i in mijn_tree.get_children():
            mijn_tree.delete(i)
        
        for rij in rijen:
            mijn_tree.insert(parent="", index = "end",values=rij)
    
    def verwijderrecord():
        select_records = mijn_tree.focus()
        
        if select_records:
            antwoord = messagebox.askyesno("Controle","Weet u zeker")
            if antwoord:       
                waarde = mijn_tree.item(select_records,"values")
                vluchtservice.verwijder_klant(waarde[0])
                toonklant()
                   
        else:
            messagebox.showwarning("Controle","U moet een vlucht selecteren")
    
    windowproduct = ttk.Window(themename="morph")
    windowproduct.geometry("2000x2000")
    windowproduct.title("vluchten")
    windowproduct.bind("<Map>",toonklant)
    heading = ttk.Label(windowproduct, text="vlucht beheer", width=1100, bootstyle="dark", font=("Calibri", "18", "bold"),
                        background="#2c3e50", foreground="white", anchor="center", justify="center")
    heading.pack()

    heading_frame = ttk.Frame(windowproduct, bootstyle="dark", width=1100)
    heading_frame.pack()
    mijn_tree = ttk.Treeview(windowproduct)

    vertrekuur_text = tk.Label(windowproduct,text = "vertrekuur  ",font=("Calibri", "12"))
    vertrekdatum_text = tk.Label(windowproduct,text = "vertrekdatum  ",font=("Calibri", "12"))
    aankomstuur_text = tk.Label(windowproduct,text = "aankomstuur  ",font=("Calibri", "12"))
    maxpassagier_text = tk.Label(windowproduct,text = "Aantal passagiers  ",font=("Calibri", "12"))
    maatschappij_text = tk.Label(windowproduct,text= "maatschappij?  ", wraplength=350, justify='left')
    prijs_text = tk.Label(windowproduct,text= "Prijs?  ", wraplength=350, justify='left')

    bestand = open("maatsch.txt","r")
    landen = []
    for item in bestand:
        landen.append(item.strip())
    
    maatschappij_combo= Combobox(windowproduct,width=30,height=10,values=landen)
    maatschappij_combo.set("selecteren")
    maatschappij_combo.place(x=250,y=280)


    vertrekuur_text.place(x=15,y=60)
    vertrekdatum_text.place(x=15,y=100)
    aankomstuur_text.place(x=15,y=160)
    maxpassagier_text.place(x=15,y=220)
    maatschappij_text.place(x=15,y=270)
    prijs_text.place(x=15,y=320)



    vertrekuur = tk.StringVar()
    vertrekdatum = tk.StringVar()
    aankomstuur = tk.StringVar()
    maxpassagier  = tk.StringVar()
    prijs = tk.StringVar()


    vertrekuur_input = tk.Entry(windowproduct,textvariable = vertrekuur, width = "30",font=("Calibri", "12"))
    vertrekdatum_input = ttk.DateEntry(windowproduct, bootstyle="danger")
    aankomstuur_input = tk.Entry(windowproduct,textvariable = aankomstuur , width = "30",font=("Calibri", "12"))
    maxpassagier_input = tk.Entry(windowproduct,textvariable = maxpassagier , width = "30",font=("Calibri", "12"))
    prijs_input = tk.Entry(windowproduct,textvariable = prijs , width = "30",font=("Calibri", "12"))


    vertrekuur_input.place(x=250,y=60)
    vertrekdatum_input.place(x=250,y=110)
    aankomstuur_input.place(x=250,y=160)
    maxpassagier_input.place(x=250,y=220)
    prijs_input.place(x=250,y=320)
    


    mijn_tree['columns'] = ("vlucht_id","vertrekuur","vertrekdatum","aankomstuur","maxpassagier","maatschappij","Prijs")

    mijn_tree.heading("#0", text = "Label", anchor = W)
    mijn_tree.heading("vlucht_id", text= "vlucht_id", anchor = W)
    mijn_tree.heading("vertrekuur", text= "vertrekuur", anchor = W)
    mijn_tree.heading("vertrekdatum", text= "vertrekdatum", anchor = W)
    mijn_tree.heading("aankomstuur", text= "aankomstuur", anchor = W)
    mijn_tree.heading("maxpassagier", text= "maxpassagier", anchor = W)
    mijn_tree.heading("maatschappij", text= "maatschappij", anchor = W)
    mijn_tree.heading("Prijs", text= "Prijs", anchor = W)
    
    
    mijn_tree.column("#0", width = 0, stretch = NO)
    mijn_tree.column("vlucht_id" , width = 0, stretch= NO)
    mijn_tree.column("vertrekuur" , width = 100, anchor = W)
    mijn_tree.column("vertrekdatum" , width = 100, anchor = W)
    mijn_tree.column("aankomstuur" , width = 200, anchor = W)
    mijn_tree.column("maxpassagier" , width = 100, anchor = W)
    mijn_tree.column("maatschappij" , width = 100, anchor = W)
    mijn_tree.column("Prijs" , width = 100, anchor = W)

    mijn_tree.place(x=320,y=450)


    Bewaar = tk.Button(windowproduct,text = "Voeg Toe",width="20",height = "2",command = bewaren,font=("Calibri", "12"))
    Bewaar.place(x=250,y=650)

    Verwijder = tk.Button(windowproduct,text = "Verwijderen",width="20",height = "2",command = verwijderrecord,font=("Calibri", "12"))
    Verwijder.place(x=450,y=650)

    Sluiten = tk.Button(windowproduct,text = "Sluiten",width="20",height = "2",command=sluiten,font=("Calibri", "12"))
    Sluiten.place(x=650,y=650)
    
    wijzig =tk.Button(windowproduct,text = "Wijzig",command=open_sub, width="20", height="2",font=("Calibri", "12"))
    wijzig.place(x=850,y=650)

    windowproduct.mainloop()       
    
    
if __name__ == "__main__":
    main()