maatschappij = ['KLM', 'Blue Air', 'Qatar Airways', 'Emirates', 'Lufthansa', 'Singapore Airlines', 'ANA All Nippon Airways', 'Japan Airlines', 'Qantas AirwaysÂ', 'Hainan Airlines', 'Air France', 'TUIfly', 'Vueling', 'Transavia', 'Norwegian', 'Aer Lingus']
maatschappij.sort()


