import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as tbs
from ttkbootstrap.constants import *
from tkinter.ttk import Combobox
from vlucht import main
from passegerie import aap
import matplotlib.pyplot as plt
import passegerieservice


def is_admin():
    return True

def open_passegerie():
    aap()
        
def open_vlucht():
    main() 

def een():
    def toongrafiek():
        airlines = passegerieservice.get_airlines()

        colors = ['skyblue', 'orange', 'lightgreen', 'lightcoral', 'lightcyan',
                  'lightpink', 'lightyellow', 'lightgrey', 'lightgreen', 'lightsalmon',
                  'lightblue', 'lightcoral', 'lightgreen', 'lightpink', 'lightcyan',
                  'lightyellow', 'lightgrey', 'lightgreen', 'lightsalmon', 'lightblue']

        explode = [0.1 if size == max(airlines.values()) else 0 for size in airlines.values()]

        plt.pie(list(airlines.values()), labels=list(airlines.keys()), startangle=90, autopct='%1.1f%%', colors=colors, explode=explode)
        plt.title("Hoe vaak vliegt iedere luchtvaartmaatschappij")

        plt.legend(list(airlines.keys()), loc="upper right")

        plt.axis('equal')
        plt.show()
        
    root = tbs.Window(themename="morph")
    root.geometry("1000x1000")
    root.title("Vlucht Dienst")


    heading = tk.Label(text ="Vlucht / Passagier-Service ",bg="grey",width=500,height=3)
    heading.pack()

    tk.Button(root, text="Passagier Toevoegen", width=30, height=2, bg="grey", command=open_passegerie).place(x=150, y=550)
    tk.Button(root, text="Vlucht Toevoegen", width=30, height=2, bg="grey", command=open_vlucht).place(x=620, y=550)
    tk.Button(root, text="Samenvatting Jaar", width=30, height=2, bg="grey", command=toongrafiek).place(x=380, y=600)

    root.mainloop()
    
if __name__ == "__main__":
    een()

