from tkinter import *
from tkinter import messagebox
import ttkbootstrap as tbs
import servicegebruikers
import passagiersvlucht
import samenvoeging

def nieuw(): 
    def opslaan():
        gebruiker = gebruikersnaam.get()
        pasw = paswoord1.get()
        
        if gebruiker == "" or pasw == "":
            messagebox.showwarning("Fout", "Vul een geldige gebruikersnaam en wachtwoord in")
            return
        
        servicegebruikers.addgebruiker(gebruiker, pasw)
        messagebox.showinfo("Succes", "Gebruiker succesvol aangemaakt")
        sluiten()
                
                           
    def sluiten():
        aanmaakgebruiker.destroy()
        
    aanmaakgebruiker =Toplevel()   
                
    aanmaakgebruiker.geometry("400x300")
    aanmaakgebruiker.title("Aanmaak gebruiker")
    
    heading = tbs.Label(aanmaakgebruiker, text="Aanmaak gebruiker", width=1100, bootstyle="dark", font=("Calibri", "18", "bold"),
                        background="#2c3e50", foreground="white", anchor="center", justify="center")
    heading.pack()

    
    gebruikersnaam = StringVar()
    paswoord1 = StringVar()
    paswoord2 = StringVar()

    gebruikersnaam_text = Label(aanmaakgebruiker,text="Gebruikersnaam",)
    paswoord_text = Label(aanmaakgebruiker,text="Paswoord")
    paswoord2_text = Label(aanmaakgebruiker,text="Herhaal paswoord")
    
    gebruikersnaam_text.place(x=15,y=60)
    paswoord_text.place(x = 15,y = 100)
    paswoord2_text.place(x = 15,y = 140)

    gebruikernaam_entry = Entry(aanmaakgebruiker,textvariable=gebruikersnaam, width='32')
    paswoord_entry = Entry(aanmaakgebruiker,textvariable=paswoord1, width='32', show='*')
    paswoord2_entry = Entry(aanmaakgebruiker,textvariable=paswoord2, width='32', show='*')
    
    gebruikernaam_entry.place(x = 130,y=60)
    paswoord_entry.place(x=130,y=100)
    paswoord2_entry.place(x=130,y=140)
    
    opslaan_button = Button(aanmaakgebruiker,text='Opslaan', width='20', height='2', command=opslaan, bg='grey')
    opslaan_button.place(x=180, y=250)
    
    sluit_button = Button(aanmaakgebruiker,text='Sluiten', width='20', height='2', command =sluiten, bg='grey')
    sluit_button.place(x=15, y=250)
       
    
def main():       
    def openmaak():
        nieuw()

    def checklog():
        gebr = gebruikersnaam.get()
        pas = paswoord.get()

        waarden = servicegebruikers.getgebruikers(gebr)

        if waarden is None:
            messagebox.showerror('Fout', 'Er is een probleem opgetreden bij het ophalen van gebruikersgegevens')
        elif not waarden:
            messagebox.showinfo('Fout', 'Deze gebruiker is niet in ons systeem')
        else:
            opgeslagen_wachtwoord = waarden[0][1]
            if pas == opgeslagen_wachtwoord:
                messagebox.showinfo('Succes', "U heeft succesvol ingelogd")
                if gebr == "Alperen":
                    inlogscherm.destroy()
                    samenvoeging.een() 
                else:
                    inlogscherm.destroy()
                    passagiersvlucht.aap() 
            else:
                messagebox.showinfo("Fout", "Ongeldig wachtwoord")

        
    inlogscherm = tbs.Window(themename="morph")  
                    
    inlogscherm.geometry("600x600")
    inlogscherm.title("inlog")
    heading = tbs.Label(inlogscherm, text="Inloggegevens", width=1100, bootstyle="dark", font=("Calibri", "18", "bold"),
                        background="#2c3e50", foreground="white", anchor="center", justify="center")
    heading.pack()


    global gebruikersnaam_entry, paswoord_entry
    gebruikersnaam = StringVar()
    paswoord = StringVar()

    gebruikersnaam_text = Label(text="Gebruikersnaam",)
    paswoord_text = Label(text="Paswoord")
    
    gebruikersnaam_text.place(x=15,y=60)
    paswoord_text.place(x = 15,y = 100)

    gebruikersnaam_entry = Entry(textvariable=gebruikersnaam, width='32')
    paswoord_entry = Entry(textvariable=paswoord, width='32', show='*')

    gebruikersnaam_entry.place(x = 150,y=60)
    paswoord_entry.place(x=150,y=100)

    inlog = Button(text='Inloggen', width='20', height='2', command=checklog, bg='grey')
    inlog.place(x=200, y=150)
    
    nieuwe_gebruiker = Button(text='Nieuwe gebruiker', width='20', height='2', command =openmaak, bg='grey')
    nieuwe_gebruiker.place(x=15, y=150)

    inlogscherm.mainloop()
    
if __name__ == "__main__":
    main()