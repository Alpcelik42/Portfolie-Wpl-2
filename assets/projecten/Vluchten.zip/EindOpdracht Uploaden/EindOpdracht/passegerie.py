import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from tkinter.ttk import Combobox
import passegerieservice 


waardencategorie = []

def is_admin():
    return False

def openform(lijst_passagiers,toongeg):
    def toon_product():
        print(lijst_passagiers)
        wid_entry.insert(0,lijst_passagiers[0])
        wnaam_entry.insert(0,lijst_passagiers[1])
        wvoornaam_entry.insert(0,lijst_passagiers[2])
        wgeboortedatum.set(lijst_passagiers[3])
        wpostcode_entry.insert(0,lijst_passagiers[4])
        wadres_entry.insert(0,lijst_passagiers[5])
        wland_combo.set(lijst_passagiers[6])
        
        wid_entry.config(state="readonly")
                
    def wijzig_item(): 
        pid = wid_entry.get()
        record = passegerieservice.bewaar_klant(wnaam_entry.get(),wvoornaam_entry.get(),wgeboortedatum.get(),wpostcode_entry.get(),wadres_entry.get(),wland_combo.get())
        
        if record > 0:
            messagebox.showinfo("Controle","De passagier is opgeslagen")
            toongeg()
            sluitform()
        else:
            messagebox.showinfo("Controle","De passagier is NIET opgeslagen")
    
    def sluitform():
        passagiersform.destroy()
    
    passagiersform = tk.Toplevel()
    passagiersform.title("Wijzig passagier")
    passagiersform.geometry("800x800")
        
    
    wid_label = tk.Label(passagiersform,text="passagiersID")
    wnaam_label=tk.Label(passagiersform,text = "naam")
    wvoornaam_label=tk.Label(passagiersform,text = "voornaam")
    wpostcode_label= tk.Label(passagiersform,text= "postcode")
    wadres_label= tk.Label(passagiersform,text= "adres")
    wland_label = tk.Label(passagiersform,text= "Gekozen land")
        
        
    wID = tk.StringVar()
    wnaam = tk.StringVar()
    wvoornaam = tk.StringVar()
    wpostcode = tk.StringVar()
    wgeboortedatum = tk.StringVar()
    wadres = tk.StringVar()
        
    bestand = open("landenapart.txt","r")
    landen = []
    for item in bestand:
        landen.append(item.strip())
        
        
    wid_entry= tk.Entry(passagiersform,textvariable=wID,width="25")
    wnaam_entry=tk.Entry(passagiersform,textvariable = wnaam,width="30")
    wvoornaam_entry=tk.Entry(passagiersform,textvariable = wvoornaam,width="50")
    wland_combo=Combobox(passagiersform, values=landen ,width="15",height="10")
    wpostcode_entry=tk.Entry(passagiersform,textvariable = wpostcode,width="30")
    wadres_entry=tk.Entry(passagiersform,textvariable = wadres,width="30")
    geboortedatum_text = tk.Label(passagiersform,text = "geboortedatum  ",font=("Calibri", "12"))
    passagiersform.bind("<Map>",toon_product())


    sluit_button = tk.Button(passagiersform,text = "sluiten",command=sluitform, width="15", height="2",bg="slategrey", fg="black")
    wijzig_button = tk.Button(passagiersform,text = "Wijzig",command=wijzig_item, width="15", height="2",bg="slategrey", fg="black")


    geboortedatum_input = ttk.DateEntry(passagiersform, bootstyle="danger")
    
    
    geboortedatum_input.place(x=550,y=20)
    geboortedatum_text.place(x=440,y=20)
    
    wid_label.place(x=15,y = 20)
    wid_entry.place(x=120,y = 20)

    wnaam_label.place(x=15, y =50)
    wnaam_entry.place(x = 120, y = 50)
        
    wvoornaam_label.place(x = 15, y = 80)
    wvoornaam_entry.place(x = 120, y = 80)
        
    wpostcode_label.place(x =15 , y = 110)
    wpostcode_entry.place(x =120, y = 110)
        
    wadres_label.place(x = 15 , y = 140)
    wadres_entry.place(x = 120,y = 140)
        
    wland_combo.place(x=120 , y= 170)
    wland_label.place(x=15 , y=170 )
    
    sluit_button.place(x= 15, y=220)
    wijzig_button.place(x = 150 , y=220)


def aap():
    def open_sub():
        if mijn_tree.focus():
            record = mijn_tree.focus()
            lijst_passagiers = mijn_tree.item(record,"values")
            openform(lijst_passagiers,toonklant())
        
    def validatie():
        if naam_input.get() == "":
            messagebox.showinfo("Controle","U moet een voornaam ingeven!")
            return None
        
        elif voornaam_input.get() =="":
            messagebox.showinfo("Controle","U moet een achternaam ingeven!")
            return None
        
        elif postcode_input.get() == "":
            messagebox.showinfo("Controle","U moet een postcode ingeven!")
            return None
        
        elif adres_input.get() == "":
            messagebox.showinfo("Controle","Er is geen geldig adres opgegeven.")
            return None
        
        elif  mijn_combo.get() == "":
            messagebox.showinfo("Controle", "Selecteer een land a.u.b")
            return None
        return True

    def bewaren():
        if validatie():
            uitkomst =  passegerieservice.bewaar_klant(naam_input.get(),voornaam_input.get(),geboortedatum_input.entry.get(),postcode_input.get(),adres_input.get(),mijn_combo.get())
            if  uitkomst > 0:
                messagebox.showinfo("Controle","De passagerie is toegevoegd")
                maakleeg()
                toonklant()
            else:
                messagebox.showwarning("Controle","De passagerei is niet toegevoegd")
          
    def maakleeg():
        naam_input.delete(0,END)
        voornaam_input.delete(0,END)
        geboortedatum_input.entry.delete(0,END)
        postcode_input.delete(0,END)
        adres_input.delete(0,END)
        mijn_combo.set("")
        naam_input.focus_get()  
                
    def sluiten():      
        windowproduct.destroy()

    def toonklant(*event):
        lijstlanden = []
        bestand = open("landenapart.txt","r")
        
        for item in bestand:
            lijstlanden.append(item)
        mijn_combo.config(value =lijstlanden)
        
        rijen = passegerieservice.toonklanten()
        
        for i in mijn_tree.get_children():
            mijn_tree.delete(i)
        
        for rij in rijen:
            mijn_tree.insert(parent="", index = "end",values=rij)
    
    def verwijderrecord():
        select_records = mijn_tree.focus()
        
        if select_records:
            antwoord = messagebox.askyesno("Controle","Weet u zeker")
            if antwoord:       
                waarde = mijn_tree.item(select_records,"values")
                passegerieservice.verwijder_klant(waarde[0])
                toonklant()   
        else:
            messagebox.showwarning("Controle","U moet een item selecteren")
    
    windowproduct = ttk.Window(themename="morph")
    windowproduct.geometry("2000x2000")
    windowproduct.title("Klanten")
    windowproduct.bind("<Map>",toonklant)
    heading = ttk.Label(windowproduct, text="passagier beheer", width=1100, bootstyle="dark", font=("Calibri", "18", "bold"),
                        background="#2c3e50", foreground="white", anchor="center", justify="center")
    heading.pack()
    heading_frame = ttk.Frame(windowproduct, bootstyle="dark", width=1100)
    heading_frame.pack()
    mijn_tree = ttk.Treeview(windowproduct)

    naam_text = tk.Label(windowproduct,text = "naam  ",font=("Calibri", "12"))
    voornaam_text = tk.Label(windowproduct,text = "voornaam  ",font=("Calibri", "12"))
    geboortedatum_text = tk.Label(windowproduct,text = "geboortedatum  ",font=("Calibri", "12"))
    postcode_text = tk.Label(windowproduct,text = "postcode  ",font=("Calibri", "12"))
    adres_text = tk.Label(windowproduct,text = "adres  ",font=("Calibri", "12"))
    Land_text = tk.Label(windowproduct,text= "welke land?  ", wraplength=350, justify='left')

    bestand = open("landenapart.txt", "r")
    landen = [item.strip() for item in bestand]
    
    mijn_combo= Combobox(windowproduct,width=30,height=10,values=landen)
    mijn_combo.set("selecteren")
    mijn_combo.place(x=740,y=60)

    naam_text.place(x=15,y=60)
    voornaam_text.place(x=15,y=100)
    geboortedatum_text.place(x=15,y=160)
    postcode_text.place(x=15,y=220)
    adres_text.place(x=15,y=270)
    Land_text.place(x=630,y=60)

    naam = tk.StringVar()
    voornaam = tk.StringVar()
    geboortedatum = tk.StringVar()
    postcode  = tk.StringVar()
    adres = tk.StringVar()

    naam_input = tk.Entry(windowproduct,textvariable = naam, width = "30",font=("Calibri", "12"))
    voornaam_input = tk.Entry(windowproduct,textvariable = voornaam, width = "30",font=("Calibri", "12"))
    postcode_input = tk.Entry(windowproduct,textvariable = postcode , width = "30",font=("Calibri", "12"))
    adres_input = tk.Entry(windowproduct,textvariable = adres , width = "30",font=("Calibri", "12"))
    geboortedatum_input = ttk.DateEntry(windowproduct, bootstyle="danger")

    naam_input.place(x=250,y=60)
    voornaam_input.place(x=250,y=110)
    geboortedatum_input.place(x=250,y=160)
    postcode_input.place(x=250,y=230)
    adres_input.place(x=250,y=280)

    mijn_tree['columns'] = ("passagier_id","naam","voornaam","geboortedatum","postcode","adres","land")

    mijn_tree.heading("#0", text = "Label", anchor = W)
    mijn_tree.heading("passagier_id", text= "passagier_id", anchor = W)
    mijn_tree.heading("naam", text= "naam", anchor = W)
    mijn_tree.heading("voornaam", text= "voornaam", anchor = W)
    mijn_tree.heading("geboortedatum", text= "geboortedatum", anchor = W)
    mijn_tree.heading("postcode", text= "postcode", anchor = W)
    mijn_tree.heading("adres", text= "adres", anchor = W)
    mijn_tree.heading("land", text= "land", anchor = W)


    mijn_tree.column("#0", width = 0, stretch = NO)
    mijn_tree.column("passagier_id" , width = 0, stretch= NO)
    mijn_tree.column("naam" , width = 100, anchor = W)
    mijn_tree.column("voornaam" , width = 100, anchor = W)
    mijn_tree.column("geboortedatum" , width = 200, anchor = W)
    mijn_tree.column("postcode" , width = 100, anchor = W)
    mijn_tree.column("adres" , width = 100, anchor = W)
    mijn_tree.column("land" , width = 100, anchor = W)

    mijn_tree.place(x=320,y=320)

    Bewaar = tk.Button(windowproduct,text = "Voeg Toe",width="20",height = "2",command = bewaren,font=("Calibri", "12"))
    Bewaar.place(x=250,y=650)

    Verwijder = tk.Button(windowproduct,text = "Verwijderen",width="20",height = "2",command = verwijderrecord,font=("Calibri", "12"))
    Verwijder.place(x=450,y=650)

    Sluiten = tk.Button(windowproduct,text = "Sluiten",width="20",height = "2",command=sluiten,font=("Calibri", "12"))
    Sluiten.place(x=650,y=650)
    
    wijzig =tk.Button(windowproduct,text = "Wijzig",command=open_sub, width="20", height="2",font=("Calibri", "12"))
    wijzig.place(x=850,y=650)

    windowproduct.mainloop()

if __name__ == "__main__":
    aap()
