from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from tkinter.ttk import Combobox
from tkinter import Toplevel
import passegerieservice
from gegevens import maatschappij
from schwifty import IBAN 
from maak_pdf import maakpdf
import webbrowser
import ttkbootstrap as tbs

def aap(): 
    def controle():
        rek = rekening.get()

        try:
            rekeningiban = IBAN(rek)
        except:
            messagebox.showwarning("Opgepaste", "Het rekening nummer klopt niet")
            return None

        result = messagebox.askyesnocancel("Controle", "Je betaling is gelukt. Wil je een pdf bestand?")
        rekeningomzet = rekeningiban.formatted

        if rekeningomzet:
            selected_vlucht = mijn_tree.focus()
            if selected_vlucht:
                vlucht = mijn_tree.item(selected_vlucht, "values")

                if result:
                    maakpdf(vlucht)
                else:
                    messagebox.showinfo("Vlucht geboekt", "Vlucht is geboekt, we wensen je een fijne vlucht!")
                root.destroy()   
                 
    def toongeg(*event):                                # gegevens opvragen uit database en tonen in treeview
        rijen = passegerieservice.selecteerpassagiers() #We gaan in de file productservices 
                                                        #De procedure selecteerproducten
                                                        #aanspreken. Deze geeft ons de gevraagde producten in een lijst(tuple).     
        for i in mijn_tree.get_children():              #We maken de treeview leeg
            mijn_tree.delete(i)
        
        for rij in rijen:
            mijn_tree.insert(parent="",index="end",values = rij ) 
           
             
    def zoek_op_id(): # zoeken op iD
        maakleeg()
        productid = zoekid.get() 
        record = passegerieservice.vlucht_by_id(productid) 
        
        if record == []:
            messagebox.showinfo("Geen resultaat","Er is geen passagier gevonden met dat id")
        else:
            naam_input.insert(0,record[0][1])     
            voornaam_input.insert(0,record[0][2])
            geboortedatum_input.insert(0,record[0][3])
            mijn_combo.set(record[0][6])   
            postcode_input.insert(0,record[0][4])
            adres_input.insert(0,record[0][5])
                 
    def maakleeg():
        naam_input.delete(0,END)   
        voornaam_input.delete(0,END)
        geboortedatum_input.delete(0,END)
        postcode_input.delete(0,END)
        adres_input.delete(0,END)
        mijn_combo.set("") 
    
    def zoek_op_maatschappij(event): 
        pr = zoekmaatschappij_combo.get()
        records = passegerieservice.vlucht_by_name(pr)
        
        for i in mijn_tree.get_children():
            mijn_tree.delete(i)
            
        for record in records:
            mijn_tree.insert(parent="",index="end",values=record)
                           
    def boek_vlucht():
        selected_passagier = mijn_tree.focus()

        if selected_passagier:
            passagier = mijn_tree.item(selected_passagier, "values")
            passagier_id = passagier[1]

            selected_vlucht = mijn_tree.focus()
            if selected_vlucht:
                vlucht = mijn_tree.item(selected_vlucht, "values")
                vlucht_id = vlucht[0] 

                aankofers = int(aankofers_input.get())
                gewicht = int(gewicht_input.get())

                result = passegerieservice.boek_vlucht(zoekid.get(), vlucht_id, aankofers, gewicht)
                if result > 0:
                    messagebox.showinfo("Controle", "Deze vlucht met deze passagier is toegevoegd aan de winkelwagen")
                    show_booking_details(passagier, vlucht, aankofers, gewicht)
                else:
                    messagebox.showwarning("Controle", "De passagier kon niet worden geboekt op de vlucht")
        else:
            messagebox.showwarning("Controle", "Selecteer een passagier")
       
    def show_booking_details(passagier, vlucht, aankofers, gewicht):
        global rekening
        booking_window = Toplevel()
        booking_window.title("Boeking Details")
        booking_window.geometry("2000x2000")

        booking_tree = ttk.Treeview(booking_window)
        booking_tree['columns'] = ("label", "value")

        booking_tree.heading("#0", text="", anchor=W)
        booking_tree.heading("label", text="Informatie", anchor=W)
        booking_tree.heading("value", text="Gegevens", anchor=W)

        labels_vlucht = ["vlucht_id", "vertrekuur", "vertrekdatum", "aankomstuur", "maxpassagier", "maatschappij", "prijs"]
        
        for label, value in zip(labels_vlucht, vlucht):
            booking_tree.insert("", index="end", values=(label, value), tags=('vlucht',))

        booking_tree.insert("", index="end", values=("Aankofers", aankofers), tags=('aankofers',))
        booking_tree.insert("", index="end", values=("Gewicht", gewicht), tags=('gewicht',))

        booking_tree.tag_configure('passagier', background='lightblue')
        booking_tree.tag_configure('vlucht', background='lightgreen')
        booking_tree.tag_configure('aankofers', background='lightyellow')
        booking_tree.tag_configure('gewicht', background='lightyellow')
        
         
        base_price = float(vlucht[6])  
        extra_weight_cost = 120 if gewicht > 80 else 0
        extra_baggage_cost = 50 * (aankofers - 1) if aankofers > 5 else 0
        total_amount = base_price + extra_weight_cost + extra_baggage_cost

        total_label = Label(booking_window, text=f"Totaal te betalen: {total_amount} Euro", font=("Helvetica", 14))
        total_label.place(x=450, y=400)

        iban = StringVar()
        rekening = StringVar()
        
        iban_label = Label(booking_window,text="Iban-nummer: ")
        iban_input = Entry(booking_window,textvariable=rekening,width="30")
        
        iban_button = Button(booking_window, text="Betalen", width="30", command=controle, height="3",bg="slategrey", fg="black")

        iban_label.place(x=330,y=450)
        iban_input.place(x=500,y=450)
        iban_button.place(x=450,y=500)

        booking_tree.place(x=300, y=100)
        
    def open_airline_website(event):
        selected_vlucht = mijn_tree.focus()
        if selected_vlucht:
            vlucht = mijn_tree.item(selected_vlucht, "values")
            maatschappij = vlucht[5]
            urls = {
                "klm": "https://www.klm.com/",
                "qatar airways": "https://www.qatarairways.com/",
                "emirates": "https://www.emirates.com/",
                "lufthansa": "https://www.lufthansa.com/be/en/homepage",
                "singapore airlines": "https://www.singaporeair.com/",
                "ana all nippon airways": "https://www.ana.co.jp/",
                "japan airlines": "https://www.jal.co.jp/",
                "qantas airways": "https://www.qantas.com/",
                "hainan airlines": "https://www.hainanairlines.com/",
                "air france": "https://www.airfrance.fr/",
                "tuifly": "https://www.tuifly.nl/",
                "vueling": "https://www.vueling.com/",
                "transavia": "https://www.transavia.com/",
                "wizz air": "https://wizzair.com/",
                "corendon airlines": "https://www.corendon.com/",
                "ryanair": "https://www.ryanair.com/",
                "easyjet": "https://www.easyjet.com/",
                "pegasus airlines": "https://www.flypgs.com/en",
                "eurowings": "https://www.eurowings.com/",
                "bue air": "https://www.blueairweb.com/",
                "corendon airlines": "https://www.corendon.com/",
                "ryanair": "https://www.ryanair.com/",
                "easyJet": "https://www.easyjet.com/nl/",
                "sunexpress": "https://www.sunexpress.com/en/",
                "croatia airlines": "https://www.croatiaairlines.com/"  
            }
            url = urls.get(maatschappij.lower(), "https://www.google.com/search?q=" + maatschappij.lower())
            webbrowser.open(url)
        

    root = tbs.Window(themename="morph")
    root.title("Passagiers")
    root.geometry("2000x2000")
    root.bind("<Map>",toongeg)
    mijn_tree = ttk.Treeview(root)
    
    mijn_tree.bind("<Double-1>", open_airline_website)
    
    #labels
    naam_label=Label(root,text = "naam")
    voornaam_label=Label(text = "voornaam")
    geboortedatum_label=Label(text= "geboortedatum")
    adres_label=Label(text="Adres")
    postcode_label= Label(text= "postcode")
    land_label= Label(text= "land")
    gewicht_label = Label(text="gewicht")
    aankofers_label = Label(text="aantal koffers")
    dubbel_label = Label(text="Dubbel klik op de treeview om meer \n informatie zien over de maatschappij.")

    naam = StringVar()
    voornaam = StringVar()
    postcode = StringVar()
    adres = StringVar()
    zoekid = StringVar()
    zoeknaam= StringVar()
    geboortedatum = StringVar()
    gewicht = IntVar()
    aankofers = IntVar()
    
    bestand = open("landenapart.txt","r")
    landen = []
    for item in bestand:
        landen.append(item.strip())
        
    
    naam_input=Entry(root,textvariable = naam,width="30")
    voornaam_input=Entry(root,textvariable = voornaam,width="50")
    
 
    postcode_input=Entry(root,textvariable = postcode,width="30")
    mijn_combo=Combobox(root,values= landen,width="15",height=2)
    zoekmaatschappij_combo=Combobox(root,values= maatschappij,width="15",height=15)
    adres_input=Entry(root,textvariable = adres,width="30")
    geboortedatum_input=Entry(root,textvariable=geboortedatum,width="30")
    gewicht_input=Entry(root,textvariable=gewicht,width="30")
    aankofers_input=Entry(root,textvariable=aankofers,width="30")
    
    
    zoekmaatschappij_combo.bind("<<ComboboxSelected>>",zoek_op_maatschappij)


    zoekid_entry=Entry(root,textvariable = zoekid,width="30")
    
    
    mijn_tree['columns'] = ("vlucht_id","vertrekuur","vertrekdatum","aankomstuur","maxpassagier","maatschappij","Prijs")

    mijn_tree.heading("#0", text = "Label", anchor = W)
    mijn_tree.heading("vlucht_id", text = "vlucht_id", anchor = W)
    mijn_tree.heading("vertrekuur", text = "vertrekuur", anchor = W)
    mijn_tree.heading("vertrekdatum",text ="vertrekdatum", anchor = W)
    mijn_tree.heading("aankomstuur", text = "aankomstuur", anchor = W)
    mijn_tree.heading("maxpassagier", text = "maxpassagier", anchor = W)
    mijn_tree.heading("maatschappij", text = "maatschappij", anchor = W)
    mijn_tree.heading("Prijs", text = "Prijs", anchor = W)

    
    mijn_tree.column("#0", width=0, stretch = NO)
    mijn_tree.column("vlucht_id", width=60, anchor = W)
    mijn_tree.column("vertrekuur", width=150, anchor = W)
    mijn_tree.column("vertrekdatum",width=150, anchor = W)
    mijn_tree.column("aankomstuur", width=150, anchor = W)
    mijn_tree.column("maxpassagier", width=60, anchor = W)
    mijn_tree.column("maatschappij", width=60, anchor = W)
    mijn_tree.column("Prijs", width=60, anchor = W)
    
    
    mijn_tree.place(x=15,y=500)
    
    
    zoekid_button = Button(root,text = "Zoek op id ",command=zoek_op_id, width="15", height="2",bg="slategrey", fg="black")
    zoekmaatschappij_button = Button(root,text = "zoek op maatschappij",command=zoek_op_maatschappij, width="25", height="2",bg="slategrey", fg="black")
    boek_button = Button(root,text= "Boek Vlucht" ,command=boek_vlucht, width="15",height="2",bg="slategrey", fg="black")
    sluit_button =Button(root,text = "Sluiten",command=root.destroy, width="15", height="2",bg="slategrey", fg="black")
    
   
    dubbel_label.place(x=750,y=350)
    aankofers_label.place(x=15,y=310)
    aankofers_input.place(x=120,y=310)
    
    gewicht_label.place(x=15,y=340)
    gewicht_input.place(x=120,y=340)
    
    zoekid_entry.place(x=15,y=40)
    zoekmaatschappij_combo.place(x=200,y=150)
    
    naam_label.place(x = 320, y = 50)
    naam_input.place(x = 435, y = 50)
    
    voornaam_label.place(x = 320, y = 80)
    voornaam_input.place(x = 435, y = 80)
    
    adres_input.place(x=435,y=190)
    adres_label.place(x=320,y=190)
    
    geboortedatum_label.place(x= 320 , y=125)
    geboortedatum_input.place(x=435 , y=125)
    
    zoekmaatschappij_combo.place(x=15,y=150)
    
    land_label.place(x =320 , y = 220)
    mijn_combo.place(x = 435,y = 220)
    
    postcode_label.place(x = 320 , y = 160)
    postcode_input.place(x = 435,y = 160)
    
    zoekid_button.place(x= 15, y=70)
    
    boek_button.place(x=15,y=800)
    
    zoekmaatschappij_button.place(x=15,y=200)
    
    sluit_button.place(x=550,y=800)
        
    root.mainloop()

if __name__ == "__main__":
    aap()
    